from tkinter import *
from translate import Translator
from gtts import gTTS
from playsound import playsound


def start():
    root.destroy()
    Screen = Tk()
    Screen.configure(bg="lemon chiffon")
    Screen.geometry('800x450')
    InputLanguageChoice = StringVar()
    TranslateLanguageChoice = StringVar()
    
    LanguageChoices = {'Hindi','English','French','German','Spanish','Telugu','Korean','Kannada','Tamil','Bengali'}
    InputLanguageChoice.set('English')
    TranslateLanguageChoice.set('Hindi')
    def Translate():
        translator = Translator(from_lang= InputLanguageChoice.get(),to_lang=TranslateLanguageChoice.get())
        Translation = translator.translate(TextVar.get())
        OutputVar.set(Translation)

    
    InputLanguageChoiceMenu = OptionMenu(Screen,InputLanguageChoice,*LanguageChoices)
    Label(Screen,text="Choose a Language",font = "arial 15 bold",bg='lemon chiffon').place(x=100,y=40)
    InputLanguageChoiceMenu.place(x=150,y=90)
 

    NewLanguageChoiceMenu = OptionMenu(Screen,TranslateLanguageChoice,*LanguageChoices)
    Label(Screen,text="Translated Language",font = 'arial 15 bold',bg='lemon chiffon').place(x=500,y=40)
    NewLanguageChoiceMenu.place(x=575,y=90)
    Label(Screen,text="Enter Text",font = 'arial 15 bold',bg='lemon chiffon').place(x=350,y=140)
    TextVar = StringVar()
    TextBox = Entry(Screen,textvariable=TextVar,width='50').place(x=250,y=190)
 
    Label(Screen,text="Output Text",font = 'arial 15 bold',bg='lemon chiffon').place(x=343,y=310)
    OutputVar = StringVar()
    TextBox = Entry(Screen,textvariable=OutputVar,width='50').place(x=250,y=360)
 

    B = Button(Screen,text="Translate",command=Translate, relief = GROOVE,font = 'arial 15 bold',bg='yellow').place(x=350,y=240)
    def play():
        Message = OutputVar.get()
        speech = gTTS(text = Message)
        speech.save('text-to-voice-converter.mp3')
        playsound('text-to-voice-converter.mp3')
    b2=Button(Screen, text = "PLAY", font = 'arial 15 bold' , command = play , bg = 'lightgreen').place(x=365,y=390)

    
root=Tk()
root.title("Language Translator")
root.geometry('800x450')
root.configure(bg='lemon chiffon')
Label(root,text="LANGUAGE TRANSLATOR",font=("Times New Roman",30),fg='red',bg='thistle2').place(x=150,y=100)
b1=Button(root,text="START",command=start,font = 'arial 15 bold',bg = 'lightgreen').place(x=350,y=200)

root.mainloop()
